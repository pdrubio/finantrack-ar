# FinanTrack AR 🇦🇷

Dashboard financiero argentino con datos en tiempo real.

## Estructura del proyecto

```
finantrack-ar/
├── public/
│   └── index.html          ← El sitio web (subí el archivo que generó Claude acá)
├── netlify/
│   └── functions/
│       └── actualizar-datos.mjs  ← Se ejecuta cada día a las 8am automáticamente
├── netlify.toml            ← Configuración de Netlify
├── package.json
└── README.md
```

## Cómo subir el sitio

1. Creá una cuenta en github.com
2. Creá un repositorio llamado `finantrack-ar`
3. Subí TODOS estos archivos respetando la estructura de carpetas
4. Conectá el repo a netlify.com (Sign up → Add site → GitHub)
5. ¡Listo! El sitio queda en vivo en finantrack-ar.netlify.app

## Cómo actualizar los datos manualmente

Para actualizar tasas de bancos, billeteras o bonos:

1. Abrí el archivo `netlify/functions/actualizar-datos.mjs`
2. Editá los valores en las secciones marcadas con `// EDITÁ ESTOS VALORES`
3. Guardá y commiteá en GitHub
4. Netlify redeploya automáticamente en ~30 segundos

## Datos en tiempo real (automáticos)
- ✅ Dólar blue / oficial → bluelytics.com.ar
- ✅ Criptomonedas top 20 → CoinGecko API

## Datos actualizados 1 vez por día (automáticos via Netlify Function)
- 🔄 Tasas bancarias
- 🔄 Rendimientos de billeteras
- 🔄 Bonos y licitaciones

## Datos manuales (actualizás vos cuando cambian)
- 📝 Tasas de tarjetas de crédito
- 📝 Créditos hipotecarios UVA
- 📝 FCI institucionales
- 📝 Acciones BYMA y USA (requieren API de pago para tiempo real)

## Para dominio propio (ej: finantrack.com.ar)
1. Comprá el dominio en NIC.ar (AR$2000/año aprox.) o Namecheap
2. En Netlify: Site settings → Domain management → Add domain
3. Seguí las instrucciones para apuntar el DNS

## Para monetizar con publicidad
- Google AdSense: google.com/adsense (requiere 1000+ visitas/mes)
- Reemplazá los espacios marcados "publicidad" por el código de AdSense

## Soporte
Ante cualquier duda, abrí el chat con Claude y pedile ayuda.
