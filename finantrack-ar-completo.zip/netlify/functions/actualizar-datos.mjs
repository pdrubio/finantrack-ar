/**
 * FinanTrack AR — Función programada de actualización de datos
 * Se ejecuta automáticamente todos los días a las 8:00 AM (hora Argentina)
 * 
 * Fuentes de datos:
 *  - Dólar: bluelytics.com.ar (gratuita, sin API key)
 *  - Cripto: coingecko.com (gratuita, sin API key)
 *  - Tasas bancos / billeteras: datos estáticos actualizados manualmente acá
 *  - FCI / Rendimientos: datos estáticos actualizados manualmente acá
 * 
 * Para actualizar tasas de bancos o billeteras:
 *  Simplemente editá los objetos TASAS_BANCOS, RENDIMIENTOS_BILLETERAS, etc.
 *  y commiteá el cambio en GitHub. Netlify redeploya solo.
 */

import { schedule } from "@netlify/functions";

// ============================================================
// DATOS ESTÁTICOS — EDITÁ ESTOS VALORES CUANDO CAMBIEN
// ============================================================

const TASAS_BANCOS = [
  { banco: "Banco Nación (BNA)",     tipo: "Público",  compra: 1033, venta: 1053 },
  { banco: "Banco Provincia",        tipo: "Público",  compra: 1030, venta: 1055 },
  { banco: "Banco Ciudad",           tipo: "Público",  compra: 1035, venta: 1058 },
  { banco: "Banco Galicia",          tipo: "Privado",  compra: 1038, venta: 1062 },
  { banco: "Santander",              tipo: "Privado",  compra: 1036, venta: 1060 },
  { banco: "BBVA Argentina",         tipo: "Privado",  compra: 1037, venta: 1061 },
  { banco: "HSBC",                   tipo: "Privado",  compra: 1040, venta: 1065 },
  { banco: "Banco Macro",            tipo: "Privado",  compra: 1034, venta: 1058 },
  { banco: "ICBC",                   tipo: "Privado",  compra: 1039, venta: 1063 },
  { banco: "Banco Supervielle",      tipo: "Privado",  compra: 1036, venta: 1062 },
  { banco: "Banco Patagonia",        tipo: "Privado",  compra: 1033, venta: 1057 },
  { banco: "Banco Comafi",           tipo: "Privado",  compra: 1035, venta: 1060 },
  { banco: "Brubank",                tipo: "Digital",  compra: 1042, venta: 1068 },
];

const TASAS_BILLETERAS_DOLAR = [
  { billetera: "MercadoPago",   producto: "Dólar MEP", compra: 1148, venta: 1155, comision: "0%",   liquidez: "Inmediata" },
  { billetera: "Ualá",          producto: "Dólar MEP", compra: 1146, venta: 1153, comision: "0%",   liquidez: "Inmediata" },
  { billetera: "Naranja X",     producto: "Dólar MEP", compra: 1144, venta: 1151, comision: "0%",   liquidez: "Inmediata" },
  { billetera: "Brubank",       producto: "Dólar MEP", compra: 1149, venta: 1157, comision: "0%",   liquidez: "Inmediata" },
  { billetera: "Personal Pay",  producto: "Dólar MEP", compra: 1145, venta: 1152, comision: "0.5%", liquidez: "Inmediata" },
  { billetera: "Lemon Cash",    producto: "USDT",      compra: 1178, venta: 1185, comision: "1%",   liquidez: "Inmediata" },
  { billetera: "Ripio",         producto: "USDT",      compra: 1176, venta: 1183, comision: "1%",   liquidez: "Inmediata" },
  { billetera: "Prex",          producto: "Dólar Prex",compra: 1052, venta: 1075, comision: "2.2%", liquidez: "24hs" },
];

const RENDIMIENTOS_BILLETERAS = [
  { nombre: "MercadoPago",        tna: 99,  tea: 174.6, limite: "$10.000.000", fci: "Fima Premium",    mejor: true  },
  { nombre: "Ualá",               tna: 95,  tea: 165.3, limite: "$5.000.000",  fci: "Propio",          mejor: false },
  { nombre: "Naranja X",          tna: 92,  tea: 158.8, limite: "$3.000.000",  fci: "Naranja X Plus",  mejor: false },
  { nombre: "Brubank",            tna: 91,  tea: 156.9, limite: "$2.000.000",  fci: "Balanz",          mejor: false },
  { nombre: "Personal Pay",       tna: 88,  tea: 150.2, limite: "$1.000.000",  fci: "Schroder",        mejor: false },
  { nombre: "Lemon Cash",         tna: 86,  tea: 146.4, limite: "$500.000",    fci: "Propio",          mejor: false },
  { nombre: "Claro Pay",          tna: 85,  tea: 144.5, limite: "$500.000",    fci: "Santander",       mejor: false },
  { nombre: "Banco Galicia ON24", tna: 82,  tea: 136.4, limite: "Sin límite",  fci: "Fima Premium",    mejor: false },
  { nombre: "Santander Supera+",  tna: 80,  tea: 132.1, limite: "Sin límite",  fci: "Superfondo",      mejor: false },
  { nombre: "BBVA Invest",        tna: 78,  tea: 128.3, limite: "Sin límite",  fci: "BBVA Pesos",      mejor: false },
  { nombre: "Macro MAF",          tna: 76,  tea: 124.5, limite: "Sin límite",  fci: "MAF Pesos",       mejor: false },
  { nombre: "Banco Nación (PF)",  tna: 65,  tea: 100.4, limite: "Sin límite",  fci: "Plazo fijo 30d",  mejor: false },
];

const TASAS_CREDITOS = {
  tarjetas: [
    { entidad: "Banco Nación",  tft_mensual: 7.2, tft_anual: 86.4, cft: 142, cuotas_sin_int: 3 },
    { entidad: "Banco Galicia", tft_mensual: 8.1, tft_anual: 97.2, cft: 158, cuotas_sin_int: 6 },
    { entidad: "Santander",     tft_mensual: 7.9, tft_anual: 94.8, cft: 154, cuotas_sin_int: 6 },
    { entidad: "BBVA",          tft_mensual: 7.8, tft_anual: 93.6, cft: 151, cuotas_sin_int: 6 },
    { entidad: "HSBC",          tft_mensual: 8.4, tft_anual: 100.8,cft: 162, cuotas_sin_int: 3 },
    { entidad: "Macro",         tft_mensual: 7.5, tft_anual: 90.0, cft: 147, cuotas_sin_int: 6 },
    { entidad: "Naranja X",     tft_mensual: 9.2, tft_anual: 110.4,cft: 178, cuotas_sin_int: 3 },
  ],
  hipotecarios: [
    { banco: "Banco Nación",    tasa_uva: 3.5,  monto_max: "$350M", porcentaje: "75%", plazo: "30 años" },
    { banco: "Hipotecario",     tasa_uva: 4.0,  monto_max: "$600M", porcentaje: "80%", plazo: "30 años" },
    { banco: "Ciudad",          tasa_uva: 3.75, monto_max: "$320M", porcentaje: "75%", plazo: "30 años" },
    { banco: "Santander",       tasa_uva: 5.5,  monto_max: "$450M", porcentaje: "70%", plazo: "30 años" },
    { banco: "BBVA",            tasa_uva: 5.25, monto_max: "$400M", porcentaje: "75%", plazo: "25 años" },
  ],
};

const BONOS = [
  { ticker: "GD29", desc: "Global 2029 Ley NY", tir: 14.2, precio: 68.40, duracion: "3.8 años" },
  { ticker: "GD30", desc: "Global 2030 Ley NY", tir: 12.8, precio: 72.50, duracion: "4.5 años", hot: true },
  { ticker: "GD35", desc: "Global 2035 Ley NY", tir: 11.4, precio: 65.20, duracion: "7.2 años" },
  { ticker: "GD41", desc: "Global 2041 Ley NY", tir: 11.8, precio: 61.80, duracion: "9.8 años" },
  { ticker: "AL30", desc: "Bonar 2030 Ley AR",  tir: 13.5, precio: 70.10, duracion: "4.2 años" },
  { ticker: "AL35", desc: "Bonar 2035 Ley AR",  tir: 11.9, precio: 63.40, duracion: "7.0 años" },
];

const PROXIMAS_LICITACIONES = [
  { nombre: "TX27 BONCER",   fecha: "20 mar", fuente: "Tesoro", color: "amber" },
  { nombre: "ON Vista Energy",fecha: "22 mar", fuente: "MAV",    color: "teal"  },
  { nombre: "LECAP S31L5",   fecha: "28 mar", fuente: "BCRA",   color: "gray"  },
];

const DATOS_BCRA = {
  tasa_politica_monetaria: 29,
  inflacion_mensual: 2.4,
  inflacion_periodo: "Febrero 2025",
};

// ============================================================
// FUNCIÓN PRINCIPAL — no hace falta editar esto
// ============================================================

const handler = schedule("0 11 * * *", async () => {
  // Se ejecuta a las 11:00 UTC = 08:00 Argentina (UTC-3)
  
  console.log("FinanTrack AR — iniciando actualización de datos:", new Date().toISOString());

  let dolarData = null;
  let criptoData = null;

  // 1. Traer datos de dólar (bluelytics)
  try {
    const res = await fetch("https://api.bluelytics.com.ar/v2/latest");
    if (res.ok) {
      dolarData = await res.json();
      console.log("Dólar actualizado OK");
    }
  } catch (e) {
    console.error("Error fetching dólar:", e.message);
  }

  // 2. Traer top 20 criptos (CoinGecko)
  try {
    const ids = "bitcoin,ethereum,tether,solana,binancecoin,usd-coin,ripple,cardano,dogecoin,polkadot,matic-network,chainlink,avalanche-2,uniswap,litecoin,stellar,cosmos,monero,tron,ethereum-classic";
    const res = await fetch(
      `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&per_page=20&page=1&sparkline=false&price_change_percentage=24h`
    );
    if (res.ok) {
      criptoData = await res.json();
      console.log("Cripto actualizado OK:", criptoData.length, "monedas");
    }
  } catch (e) {
    console.error("Error fetching cripto:", e.message);
  }

  // 3. Armar el objeto de datos completo
  const datos = {
    ultima_actualizacion: new Date().toISOString(),
    dolar: dolarData,
    cripto: criptoData,
    bancos: TASAS_BANCOS,
    billeteras_dolar: TASAS_BILLETERAS_DOLAR,
    rendimientos: RENDIMIENTOS_BILLETERAS,
    creditos: TASAS_CREDITOS,
    bonos: BONOS,
    licitaciones: PROXIMAS_LICITACIONES,
    bcra: DATOS_BCRA,
  };

  console.log("Datos preparados. Actualización completada OK.");

  // En una implementación completa, acá guardarías los datos en
  // Netlify Blobs (almacenamiento incluido en el plan gratuito)
  // para que el frontend los lea sin hacer llamadas externas.
  // Por ahora, el frontend llama directamente a las APIs.

  return {
    statusCode: 200,
    body: JSON.stringify({ ok: true, ts: datos.ultima_actualizacion }),
  };
});

export { handler };
